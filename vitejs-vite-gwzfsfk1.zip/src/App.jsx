import { useState, useEffect, useRef, useCallback } from 'react';
import { motion } from 'framer-motion';
import './App.css';

const WEBHOOK_URL = 'https://ajayreddy0208.app.n8n.cloud/webhook-test/Jarvis';

const blobVariants = {
  idle: { scale: 1, borderRadius: '50%' },
  listening: {
    scale: 1.2,
    borderRadius: ['50%', '40%', '60%', '45%', '50%'],
    transition: { duration: 1, repeat: Infinity },
  },
  processing: {
    rotate: 360,
    transition: { duration: 2, repeat: Infinity, ease: 'linear' },
  },
  speaking: {
    scale: [1, 1.3, 1],
    borderRadius: ['50%', '30%', '60%', '40%', '50%'],
    transition: { duration: 0.6, repeat: Infinity },
  },
};

export default function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [mainInput, setMainInput] = useState('');
  const [status, setStatus] = useState('idle');
  const [gennyOpen, setGennyOpen] = useState(false);

  const recognitionRef = useRef(null);
  const messagesEndRef = useRef(null);
  const gennyInputRef = useRef(null);
  // Stable ref so SpeechRecognition's onresult always calls the latest processMessage
  const processMessageRef = useRef(null);

  // Load chat history
  useEffect(() => {
    const saved = localStorage.getItem('genny_chat');
    if (saved) setMessages(JSON.parse(saved));
  }, []);

  // Save chat + auto scroll
  useEffect(() => {
    localStorage.setItem('genny_chat', JSON.stringify(messages));
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Focus genny input when panel opens
  useEffect(() => {
    if (gennyOpen) {
      setTimeout(() => gennyInputRef.current?.focus(), 400);
    }
  }, [gennyOpen]);

  // Init SpeechRecognition once — use ref so onresult always has latest processMessage
  useEffect(() => {
    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    const rec = new SpeechRecognition();
    rec.lang = 'en-US';
    rec.continuous = false;
    rec.interimResults = false;

    rec.onstart = () => setStatus('listening');

    // Always call via ref — avoids stale closure on processMessage
    rec.onresult = (e) => {
      const text = e.results[0][0].transcript;
    
      console.log("VOICE INPUT:", text); // debug
    
      // 🔥 DIRECT CALL (NO REF)
      processMessage(text);
    };

    rec.onend = () => setStatus((s) => (s === 'listening' ? 'idle' : s));
    rec.onerror = (e) => {
      console.error('Speech recognition error:', e.error);
      setStatus('idle');
    };

    recognitionRef.current = rec;
  }, []);

  // TTS
  const speak = (text) => {
    setStatus('speaking');
    const utter = new SpeechSynthesisUtterance(text);
    utter.onend = () => setStatus('idle');
    speechSynthesis.speak(utter);
  };

  // Core send logic — wrapped in useCallback so the ref stays fresh
  const processMessage = useCallback(async (msg) => {
    if (!msg) return;

    setGennyOpen(true);

    const userMsg = { role: 'user', text: msg };
    setMessages((prev) => [...prev, userMsg]);
    setStatus('processing');

    try {
      const res = await fetch(WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: msg, timestamp: new Date().toISOString() }),
      });

      const text = await res.text();
      let data;
      try { data = JSON.parse(text); } catch { data = { reply: text }; }

      const reply = data.reply || 'No response from JARVIS';
      setMessages((prev) => [...prev, { role: 'ai', text: reply }]);
      speak(reply);
    } catch (err) {
      console.error('Webhook error:', err);
      setMessages((prev) => [
        ...prev,
        { role: 'ai', text: '⚠ Unable to reach JARVIS server' },
      ]);
      setStatus('idle');
    }
  }, []);

  // Keep ref in sync with latest processMessage
  useEffect(() => {
    processMessageRef.current = processMessage;
  }, [processMessage]);

  const startListening = () => {
    const rec = recognitionRef.current;
  
    if (!rec) {
      alert('Speech recognition not supported');
      return;
    }
  
    try {
      rec.start();
    } catch (e) {
      console.warn("Already running:", e);
    }
  };

  const handleMainSend = () => {
    const msg = mainInput.trim();
    if (!msg) return;
    setMainInput('');
    processMessage(msg);
  };

  const handleGennySend = () => {
    const msg = input.trim();
    if (!msg) return;
    setInput('');
    processMessage(msg);
  };

  const statusLabels = {
    idle: 'Tap orb to speak',
    listening: 'Listening...',
    processing: 'Processing...',
    speaking: 'Speaking...',
  };

  return (
    <div className="jarvis-root">
      <div className="bg-grid" />

      {/* ===== MAIN AREA ===== */}
      <div className="main-area">

        {/* CENTER PANEL */}
        <div className="center-panel">
          <div className="corner tl" />
          <div className="corner tr" />
          <div className="corner bl" />
          <div className="corner br" />

          <div className="jarvis-title">JARVIS</div>
          <div className="jarvis-sub">Your AI Assistant</div>

          <div className="orb-wrap" onClick={startListening}>
            <div className={`orb-ring${status === 'listening' ? ' active' : ''}`} />
            <motion.div
              className="orb"
              variants={blobVariants}
              animate={status}
            />
          </div>

          <p className="status-label">{statusLabels[status] || 'Tap orb to speak'}</p>

          <div className="main-input-wrap">
            <input
              className="main-input"
              value={mainInput}
              onChange={(e) => setMainInput(e.target.value)}
              placeholder="Ask JARVIS..."
              onKeyDown={(e) => e.key === 'Enter' && handleMainSend()}
            />
            <button className="main-send-btn" onClick={handleMainSend}>➤</button>
          </div>
        </div>

        {/* GENNY CHAT PANEL */}
        <div className={`chat-panel${gennyOpen ? ' open' : ''}`}>
          <div className="chat-panel-inner">
            <div className="chat-header">
              <div className="chat-header-title">
                <div className="genny-avatar">💬</div>
                <div>
                  <div className="genny-name">ChatBox</div>
                  
                </div>
              </div>
              <button className="close-chat-btn" onClick={() => setGennyOpen(false)}>✕</button>
            </div>

            <div className="chat-messages">
              {messages.length === 0 && (
                <p className="msg-empty">No conversations yet...</p>
              )}
              {messages.map((msg, i) => (
                <div key={i} className={`msg ${msg.role}`}>
                  {msg.text}
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

           
          </div>
        </div>
      </div>
    </div>
  );
}